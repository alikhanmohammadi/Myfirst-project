import java.awt.*;
import java.util.ArrayList;

public class BeadFinder {

    //esme blob va beads to bar aks neveshtim :D
    //eshtebah motevajeh shode budam ke blob bishtar az 25 pixele
    //harja blobs bood inja manzur hamun bead hast
    private Picture picture;
    private double tau;
    private boolean[][] visited;
    private ArrayList<Blob> beads;

    public BeadFinder(Picture picture, double tau) {
        this.picture = convertGrayscale(picture);
        this.tau = tau;
        //arz o ertefaye picture va check kardane add shodane blob
        visited = new boolean[picture.width()][picture.height()];
        beads = new ArrayList<>();
        find();
    }

    public ArrayList<Blob> getBlobs(int min) {
        ArrayList<Blob> list = new ArrayList<>();
        //for-each loop for array ( new syntax)  == for (int i=0; i<arr.length; i++)
        for (Blob b : beads) {
            if (b.pixels.size() > min)
                list.add(b);
        }
        return list;
    }


    //problem
    public void find() {

        for (int i = 0; i < picture.width(); i++) {
            for (int j = 0; j < picture.height(); j++) {
                if (picture.get(i,j).getRed() >= tau) {
                    beads.add(new Blob());
                    findRecursive(beads.get(beads.size() - 1), i, j);
                }
            }
        }
    }

    public void findRecursive(Blob blob, int i, int j) {
        if (i < 0 || j < 0 || i >= picture.width() || j >= picture.height() || visited[i][j])
            return;
        if (picture.get(i,j).getRed() < tau) {
            visited[i][j] = true;
            return;
        }

        visited[i][j] = true;
        //recursive haye ma baraye peyda kardan blob haye pishe ham
        blob.add(i, j);
        findRecursive(blob, i + 1, j);
        findRecursive(blob, i - 1, j);
        findRecursive(blob, i, j + 1);
        findRecursive(blob, i, j - 1);
    }


    //noise giri tasvir.
    //tasvire ba noise migirad va tasvire bedune noise midahad
    //noise giri ba gereftane color anjam dadim vali mitoonestim RGB har rang ro begirim va ba adde Tau
    //shart begozarim
    public Picture convertGrayscale(Picture picture) {
        Picture grayscale = new Picture(picture.width(), picture.height());
        for (int col = 0; col < picture.width(); col++) {
            for (int row = 0; row < picture.height(); row++) {
                Color color = picture.get(col, row);
                int r = color.getRed();
                int g = color.getGreen();
                int b = color.getBlue();
                int y = (int) (Math.round(0.299*r + 0.587*g + 0.114*b));
                Color gray = new Color(y, y, y);
                grayscale.set(col, row, gray);
            }
        }
        return grayscale;
    }
}
